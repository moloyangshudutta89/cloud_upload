# cloud_upload

<!-- Write an install able module in python with following functionality.There are couple of files in a directory like images (jpg, png, svg, and webp), media (mp3, mp4, mpeg4, wmv, 3gp, and webm), and documents (doc, docx, csv, and pdf).
The module should read all the files from the directory and its subdirectory, upload all the images and media files to AWS S3, and all the documents to Google cloud storage.write a generic module which can be utilized as per need. The types of files to transfer to S3 and google cloud storage should be configurable.Please move the code to GitHub and share us Link.
NOTE: Please follow the below instructions:
1. The program should be developed in pure python, no frameworks should be used.
2. The program can be developed with OOPs or a functional programming approach.
3. The program must have unit test cases written with pytest and they need to have at least 85% code coverage.
4. There needs to be a README file documenting the details about the program, installation, and running guidelines. -->